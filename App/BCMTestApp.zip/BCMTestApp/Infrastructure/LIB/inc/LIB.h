/*
 * LIB.h
 *
 *  Created on: Aug 9, 2021
 *      Author: zoldeyck
 */


#ifndef __LIB__
#define __LIB__

#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "UTILS.h"

#endif
