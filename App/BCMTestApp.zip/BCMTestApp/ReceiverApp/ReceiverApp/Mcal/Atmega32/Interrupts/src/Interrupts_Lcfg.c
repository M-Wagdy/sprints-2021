/*
 * Interrupts_Lcfg.c
 *
 * Created: 8/19/2021 1:21:24 PM
 * Author: Mohamed Wagdy
 */ 

/*- INCLUDES -----------------------------------------------*/
#include "Interrupts_Lcfg.h"

Ptr_VoidFuncVoid_t aptr_ISRAddress[TABLE_SIZE] =
{
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
   NULL_PTR,
};